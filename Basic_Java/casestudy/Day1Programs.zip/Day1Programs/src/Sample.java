
public class Sample {

	public static void main(String[] args) {
		
	System.out.println("Hello World..This is my first Java Program...");
	
	}
}
